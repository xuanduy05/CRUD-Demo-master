

--
-- Siêu dữ liệu
--
USE `phpmyadmin`;

--
-- Siêu dữ liệu cho bảng data
--

--
-- Siêu dữ liệu cho cơ sở dữ liệu android
--
